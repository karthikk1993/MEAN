import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; //(for template driven forms)
import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import { NameCheckDirective } from './name-check.directive';
import { Panel, Message, SelectItem, DataTable, MenuItem, ConfirmationService,StepsModule } from "primeng/primeng";
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from "@angular/common/http";
import { AuthService } from 'src/app/services/auth.service';

@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    NameCheckDirective,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    StepsModule
  ],
  providers: [HttpClient,AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
