import { NameCheckDirective } from './name-check.directive';

describe('NameCheckDirective', () => {
  it('should create an instance', () => {
    const directive = new NameCheckDirective();
    expect(directive).toBeTruthy();
  });
});
