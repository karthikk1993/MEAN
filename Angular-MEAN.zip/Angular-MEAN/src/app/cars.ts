export class Cars {
    name:string;
    price:number;
    color:string;
    topspeed:number;
    available:boolean
    constructor(){
        this.name = undefined;
        this.price = undefined;
        this.color = undefined;
        this.topspeed = undefined;
        this.available = undefined;
    }
}
