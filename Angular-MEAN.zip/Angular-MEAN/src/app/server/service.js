const express = require('express');
const bodyparser = require ('body-parser');
const api = require('./api');
const cors = require('cors');
const app = express();

app.use(bodyparser.json());
const PORT = 3001;
app.use(cors());
app.use('/api',api);

app.get('/',(req,res)=>{
    res.send("get method works")
})

app.listen(PORT,() => {
    console.log("server listening to port 3001")
})