const express = require('express')
const router = express.Router();
const mongoose = require('mongoose');
const MongoClient = require('mongodb').MongoClient;
const User = require('./user/user')
// const uri = "mongodb://localhost/karthik"
// const client = new MongoClient(uri, { useNewUrlParser: true });

mongoose.connect('mongodb://localhost/karthik', { useNewUrlParser: true })
// client.connect(err=>{
//     if(err){
//         console.log("check connection",err)
//     }
//     else{
//         console.log("connection successful with MongoDB")
//     }
// })

router.get('/',(req,res)=>{
    res.send('From API')
})

router.post('/register',(req,res)=>{

    let userData = req.body;
    let user = new User(userData);
    user.save((error,reguser) => {
        if(error){
            console.log("check inputs",error)
        }
        else{
            console.log("success")
            res.status(200).send(reguser)
        }
    })
})

router.post('/login',(req,res)=>{
    
})



module.exports = router;