import { Injectable} from '@angular/core';
import { HttpClientModule, HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private _htttp: HttpClient) { }
  private loginUrl = 'http://localhost:3001/api/register';

  registerUser(user: any){
    return this._htttp.post(this.loginUrl,user)
  }
}
