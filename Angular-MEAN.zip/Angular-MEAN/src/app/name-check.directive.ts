import { Directive,Input} from '@angular/core';
import { NG_VALIDATORS } from '@angular/forms';
import { FormGroup, FormBuilder, Validators, FormControl,AbstractControl,ValidatorFn } from "@angular/forms";

export function forbiddenNameValidator(nameRe: RegExp): ValidatorFn {
  return (control: AbstractControl): {[key: string]: any} | null => {
    const forbidden = nameRe.test(control.value);
    console.log("con",nameRe)
    return forbidden ? {'forbiddenName': {value: control.value}} : null;
  };
}

@Directive({
  selector: '[appNameCheck]',
  providers:[{provide:NG_VALIDATORS,useExisting:NameCheckDirective,multi:true}]
})

export class NameCheckDirective implements Validators {
  @Input('appNameCheck') preventedName: string;
  constructor() { 

  }
  validate(control:AbstractControl):{[key:string]:boolean}|null{
  return this.preventedName ? forbiddenNameValidator(new RegExp(this.preventedName,'i'))(control):null
}
}
