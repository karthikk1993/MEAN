import { Component,OnInit } from '@angular/core';
import { Cars } from 'src/app/cars';
import { Login } from 'src/app/login';
import { FormsModule } from '@angular/forms'; //(for template driven forms)
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {ViewEncapsulation} from '@angular/core'
import { Panel, Message, SelectItem, DataTable, MenuItem, ConfirmationService,StepsModule } from "primeng/primeng";
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  title :string = 'KarAngular';
  unlock :boolean = false;
  carDetails :Array<Cars>;
  carCols: string[]=[];
  ironlog: Login;
  items: MenuItem[];
  constructor(private _authService: AuthService){
    const carparams = new Cars();
    Object.keys(carparams).forEach(params=>{
      this.carCols.push(params);
    })
    this.ironlog = new Login();
  }
  ngOnInit(){
    //this.carDetails = [new Cars('Ferrari',5000000,'red',225,true),new Cars('Lamborgini',7000000,'black',195,true)];
  }
  openTable(){
    if(!this.unlock) this.unlock = true;
    else this.unlock = false;
  }
  submit(){
    this.unlock = true;
    console.log("d",this.ironlog)
    this._authService.registerUser(this.ironlog).subscribe((res) => {
      res => console.log(res);
      error => console.log(error)
    })
  }
  
}
